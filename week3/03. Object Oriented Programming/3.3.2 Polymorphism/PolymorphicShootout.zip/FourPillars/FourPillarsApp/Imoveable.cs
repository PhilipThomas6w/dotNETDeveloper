﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FourPillarsApp;

public interface Imoveable
{
    public string Move();

    public string Move(int times);

    /*  public int bob(int times)
        {
            return times;
        }
    can provide default implementation if so desired


     */
}