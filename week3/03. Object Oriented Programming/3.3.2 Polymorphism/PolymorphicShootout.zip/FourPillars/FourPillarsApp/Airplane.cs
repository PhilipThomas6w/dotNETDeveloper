﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FourPillarsApp;

public class Airplane : Vehicle
{
    private string _airline;
    public int Altitude {get; set; }
    
    //implement toString what an airplane is

    public Airplane(int capacity) : base(capacity)
    {

    }

    public Airplane(int capacity, int speed, string airline) : base(capacity, speed)
    {
        _airline = airline;
    }

    public void Ascend(int distance)
    {
        Altitude += distance;
    }
    //exception for altitude
    public void Descend(int distance)
    {
        if (Altitude - distance < 0)
        {
            throw new ArgumentOutOfRangeException("Performing this action will crash the plane");
        }

        Altitude -= distance;
    }

    public override string Move()
    {

        return $"{base.Move()} at an altitude of {Altitude} metres.";
    }

    public override string Move(int times)
    {
        return $"{base.Move(times)} at an altitude of {Altitude} metres.";
    }

    public override string ToString()
    {
        string myString = $"Thank you for flying {_airline}: {base.ToString()} altitude: {Altitude}.";
        return myString;
    }
}
