﻿namespace FourPillarsApp;

public class Program
{
    static void Main(string[] args)
    {
        /*        Person matt = new Person("Matthew", "Handley");
                Console.WriteLine(matt.GetFullName());
                //matt.Age = 29;


                Person talal = new Person("Talal", "Hassan", 22);

                Console.WriteLine(talal.Age);

                //object initialisers
        *//*        Person patrick = new Person("Patrick", "Ardagh") {Age = 24, Height = 300 };
        *//*
                Park park = new Park();

                Point3D point = new Point3D(1, 2);
                Point3D empty;
                Person matthew = new Person("Matt", "Handley");


                Point3D point1 = new Point3D();

                DoThis(point, matthew);*/


/*        Dog myDog = new Dog();
        Cat myCat = new Cat();
        Bird myBird = new Bird();

        Console.WriteLine(myDog.Speak());
        Console.WriteLine(myCat.Speak());
        Console.WriteLine(myBird.Speak());

        Console.WriteLine("\nPolymorphism demo: \n");

        List<Animal> animals = new List<Animal>() { myDog, myCat, myBird };
        foreach (var animal in animals)
        {
            Console.WriteLine(animal.Speak());
        }

        Console.WriteLine();*/

 /*       Animal? myAnimal;

        string input = Console.ReadLine();

        switch (input.ToLower())
        {
            case "dog":
                myAnimal = new Dog();
                break;

            case "cat":
                myAnimal = new Cat();
                break;

            case "bird":
                myAnimal = new Bird();
                break;
            default:
                Console.WriteLine("Not an animal :(");
                break;
        }

        if (myAnimal is not null) Console.WriteLine(myAnimal.Speak());*/

/*        Console.WriteLine();

        List<Object> gameObjects = new List<Object>()
        {
            new Airplane(15),
            new Dog(),
            new Cat(),
            new Park(),
            new Person("Bob", "Dole"),
            new Hunter("Dob", "Bole", "Nikon"),
            new Vehicle()

        };

        foreach (var obj in gameObjects)
        {
            SpartaWrite(obj);
            if (obj is Animal)
            {
                Animal animal = (Animal)obj;
                SpartaWrite(animal.Speak());
            }
        }

        List<Imoveable> moveables = new()
        {
            new Airplane(15),
            new Person("Bob", "Dole"),
            new Hunter("Dob", "Bole", "Nikon"),
            new Vehicle()
        };*/

/*        foreach (var m in moveables)
        {
            SpartaWrite(m.Move(2));
        }*/

        List<IShootable> weaps = new()
        {
            new LaserGun("pew pew"),
            new WaterPistol("shoot shoot"),
            new Hunter("Dave", "Bloggs", new WaterPistol("Tez")),
            new Hunter("Joe", "Cloggs", new Camera("Kodak")),
            new Hunter("Dennis", "Reynolds", new LaserGun("Zapp"))
        };

        foreach (IShootable w in weaps)
        {
            Console.WriteLine(w);
        }

    }


    public static void DoThis(Point3D p, Person person)
    {
        p.x = 1000;
        person.Age = 99;
    }

    public static void SpartaWrite(Object obj)
    {
        Console.WriteLine($"Sparta says: {obj}");
    }
}