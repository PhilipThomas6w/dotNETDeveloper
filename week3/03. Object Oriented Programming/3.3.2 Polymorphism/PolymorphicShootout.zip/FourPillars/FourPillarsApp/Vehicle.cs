﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FourPillarsApp;

public class Vehicle : Imoveable
{
    private int _capacity;
    private int _numPassengers;

    public int NumPassengers
    {
        get
        {
            return _numPassengers;
        }
        set
        {
            if (value < 0)
            {
                _numPassengers = 0;
            }
            else if (value > _capacity)
            {
                _numPassengers = _capacity;
            }
            else
            {
                _numPassengers = value;
            }
        }
    }

    public int Position { get; private set; }

    public int Speed { get; init; } = 10;
    
    public Vehicle()
    {

    }

    public Vehicle(int capacity, int speed = 10)
    {
        _capacity = capacity;
        Speed = speed;
    }

    public virtual string Move()
    {

        Position += Speed;

        return $"Moving along";
    }
    //implement a toString of what a vehicle is

    public virtual string Move(int times)
    {

        Position += Speed * times;
        Position -= Speed;
        //implement with no arg move
        return $"Moving along {times} times";
    }

    public override string ToString()
    {
        //string[] split = this.GetType().ToString().Split("."); << this removes the namespace if necessary

        return $"{GetType()} capacity: {_capacity} passengers: {_numPassengers} speed: {Speed} position: {Position}";
    }
}
