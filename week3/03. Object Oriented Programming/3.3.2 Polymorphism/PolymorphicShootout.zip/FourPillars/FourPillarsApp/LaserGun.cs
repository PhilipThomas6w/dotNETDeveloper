﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FourPillarsApp;

public class LaserGun : Weapon
{
    public LaserGun(string brand) : base(brand)
    {

    }

    public override string Shoot()
    {
        return $"Zing!! A {base.Shoot()} has just been fired";
    }
}
