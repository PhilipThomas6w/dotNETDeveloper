﻿using FourPillarsApp;
using System.Threading.Tasks;

namespace FourPillarsTests;


/*Airplane a = new Airplane(200, 100, "JetsRUs")

{ NumPassengers = 150 };

a.Ascend(500); 

    Console.WriteLine(a.Move(3)); 

    Console.WriteLine(a); 

    a.Descend(200); 

    Console.WriteLine(a.Move()); 

    a.Move(); 

    Console.WriteLine(a)*/


/*1   Moving along 3 times at an altitude of 500 metres.

2   Thank you for flying JetsRUs: ClassesApp.Airplane capcity: 200 

     passengers: 150 speed: 100 position: 300 altitude: 500. 

3   Moving along at an altitude of 300 metres.

4   Thank you for flying JetsRUs: ClassesApp.Airplane capcity: 200 

     passengers: 150 speed: 100 position: 500 altitude: 300. */
public class AirplaneTests
{
    [TestCase(1, 1, 1)]
    [TestCase(2, 2, 2)]
    [TestCase(2, 10, 2)]
    [TestCase(2, 15, 2)]

    public void GivenValidCapacity_AirplaneOneArgCon_ReturnsExpectedCapacity(int capacity, int passengers, int expectedCap)
    {
        Airplane plane = new Airplane(capacity);
        plane.NumPassengers = passengers;
        Assert.That(plane.NumPassengers, Is.EqualTo(capacity));

    }

    [TestCase(1, 1, "a", 1, 1)]
    [TestCase(1, 10, "ab", 1, 1)]
    [TestCase(1, 1, "a", 2, 1)]
    [TestCase(2, 1, "a", 2, 2)]
    [TestCase(2, 2, "a", 2, 2)]
    [TestCase(2, 1, "ab", 2, 2)]

    public void GivenValidInput_AirplaneThreeArgCon_ReturnsExpectedCapacity(int capacity, int speed, string airline, int passengers, int expectedCap)
    {
        Airplane plane = new Airplane(capacity, speed, airline);
        plane.NumPassengers = passengers;
        Assert.That(plane.NumPassengers, Is.EqualTo(capacity));

    }

    [TestCase(1, 1, "a", 1)]
    [TestCase(2, 1, "a", 1)]
    [TestCase(1, 1, "ab", 1)]
    [TestCase(1, 2, "a", 2)]
    [TestCase(2, 2, "a", 2)]
    [TestCase(1, 2, "ab", 2)]

    public void GivenValidInput_AirplaneThreeArgCon_ReturnsExpectedSpeed(int capacity, int speed, string airline, int expectedSpeed)
    {
        Airplane plane = new Airplane(capacity, speed, airline);
        Assert.That(plane.Speed, Is.EqualTo(expectedSpeed));

    }

    [TestCase(1, 1, "BobAirways", "Thank you for flying BobAirways: FourPillarsApp.Airplane capacity: 1 passengers: 0 speed: 1 position: 0 altitude: 0.")]
    [TestCase(2, 1, "BobAirways", "Thank you for flying BobAirways: FourPillarsApp.Airplane capacity: 2 passengers: 0 speed: 1 position: 0 altitude: 0.")]
    [TestCase(1, 2, "BobAirways", "Thank you for flying BobAirways: FourPillarsApp.Airplane capacity: 1 passengers: 0 speed: 2 position: 0 altitude: 0.")]
    [TestCase(1, 1, "BobAirways1", "Thank you for flying BobAirways1: FourPillarsApp.Airplane capacity: 1 passengers: 0 speed: 1 position: 0 altitude: 0.")]

    public void GivenValidInput_AirplaneThreeArgCon_ReturnsExpectedAirline(int capacity, int speed, string airline, string expectedAirline)
    {
        Airplane plane = new Airplane(capacity, speed, airline);
        Assert.That(plane.ToString(), Is.EqualTo(expectedAirline));

    }

    [TestCase(0, 0, 0)]
    [TestCase(0, 10, 10)]
    [TestCase(0, 200, 200)]

    public void GivenValidInput_Ascend_ReturnsExpectedAltitude(int capacity,int distance, int expectedAlt)
    {
        Airplane plane = new Airplane(capacity);
        plane.Ascend(distance);
        Assert.That(plane.Altitude, Is.EqualTo(expectedAlt));
    }

    [TestCase(0, 0, 200)]
    [TestCase(0, 10, 190)]
    [TestCase(0, 200, 0)]

    public void GivenValidInput_Descend_ReturnsExpectedAltitude(int capacity, int distance, int expectedAlt)
    {
        Airplane plane = new Airplane(capacity);
        plane.Altitude = 200;
        plane.Descend(distance);
        Assert.That(plane.Altitude, Is.EqualTo(expectedAlt));
    }

    [TestCase(0, 1)]
    [TestCase(0, 10)]

    public void GivenInValidInput_Descend_ReturnsExpectedException(int capacity, int distance)
    {
        Airplane plane = new Airplane(capacity);
        Assert.That(() => plane.Descend(distance), Throws.TypeOf<ArgumentOutOfRangeException>());
    }

    [TestCase(0, 1)]
    [TestCase(0, 10)]

    public void GivenInValidInput_Descend_ReturnsExpectedExceptionMessage(int capacity, int distance)
    {
        Airplane plane = new Airplane(capacity);
        Assert.That(() => plane.Descend(distance), Throws.TypeOf<ArgumentOutOfRangeException>().With.Message.Contains("Performing this action will crash the plane"));
    }

    [TestCase(1, 500, "Moving along at an altitude of 500 metres.")]
    [TestCase(1, 1000, "Moving along at an altitude of 1000 metres.")]

    public void GivenZeroArguments_Move_ReturnsExpectedString(int capacity, int altitude, string expected)
    {
        Airplane plane = new Airplane(capacity);
        plane.Altitude = altitude;
        Assert.That(plane.Move(), Is.EqualTo(expected));
    }

    [TestCase(1, 1, 500, "Moving along 1 times at an altitude of 500 metres.")]
    [TestCase(1, 2, 1000, "Moving along 2 times at an altitude of 1000 metres.")]

    public void GivenTimes_Move_ReturnsExpectedString(int capacity, int times, int altitude, string expected)
    {
        Airplane plane = new Airplane(capacity);
        plane.Altitude = altitude;
        Assert.That(plane.Move(times), Is.EqualTo(expected));
    }

    //Continue testing
}
