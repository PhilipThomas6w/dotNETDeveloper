using FourPillarsApp;

namespace FourPillarsTests;

public class VehicleTests
{
    /*    [SetUp]
        public void Setup()
        {
        }*/

    [Test]
    public void WhenADefaultVehicle_MovesTwice_ItsPositionIs20()
    {
        Vehicle v = new Vehicle();
        var result = v.Move(2);
        int expectedPosition = 10;
        string expectedOutputString = "Moving along 2 times";
        Assert.That(v.Position, Is.EqualTo(expectedPosition));
        Assert.That(result, Is.EqualTo(expectedOutputString));
    }

    [Test]

    public void GivenZeroArgCon_Move_ReturnsExpectedValue()
    {
        Vehicle car = new Vehicle();
        string result = car.Move();
        Assert.That(car.Position, Is.EqualTo(10));
        Assert.That(result, Is.EqualTo("Moving along"));
    }

    [Test]
    public void WhenAVehicleWithSpeed40_IsMovedOnce_ItsPositionIs40()
    {
        Vehicle v = new Vehicle(5, 40);
        string result = v.Move();
        int expectedPosition = 40;
        string expectedOutputString = "Moving along";
        Assert.That(v.Position, Is.EqualTo(expectedPosition));
        Assert.That(result, Is.EqualTo(expectedOutputString));
    }

    [TestCase(20, 2, 20, "Moving along 2 times")]
    [TestCase(20, 4, 60, "Moving along 4 times")]
    [TestCase(60, 2, 60, "Moving along 2 times")]
    [TestCase(120, 4, 360, "Moving along 4 times")]
    public void GivenASpeedVehicle_MoveArg_ReturnsExpectedValue(int speed, int times, int expectedPosition, string expectedString)
    {
        Vehicle car = new Vehicle(5, speed);
        string result = car.Move(times);
        Assert.That(car.Position, Is.EqualTo(expectedPosition));
        Assert.That(result, Is.EqualTo(expectedString));
    }

    [TestCase(10, 11, 10)]
    [TestCase(10, 10, 10)]
    [TestCase(10, 9, 9)]


    public void GivenCapacity_Vehicle_CapacitySetToExpectedValue(int capacity, int passengers, int expected)
    {
        Vehicle car = new Vehicle(capacity);

        car.NumPassengers = passengers;

        Assert.That(car.NumPassengers, Is.EqualTo(expected));
    }

    [TestCase(11, 0)]
    [TestCase(9, 0)]
    public void GivenCapacity_ZeroArgConVehicle_CapacitySetToExpectedValue(int passengers, int expected)
    {
        Vehicle car = new Vehicle();

        car.NumPassengers = passengers;

        Assert.That(car.NumPassengers, Is.EqualTo(expected));
    }

    [TestCase(10, -1, 0)]
    [TestCase(10, -55, 0)]

    public void GivenBelowZero_Vehicle_NumPassengersSetToExpectedValue(int capacity, int passengers, int expected)
    {
        Vehicle car = new Vehicle(capacity);

        car.NumPassengers = passengers;

        Assert.That(car.NumPassengers, Is.EqualTo(expected));
    }

    [TestCase(-1, 0)]
    [TestCase(-10, 0)]
    public void GivenBelowZero_ZeroArgConVehicle_NumPassengersSetToExpectedValue(int passengers, int expected)
    {
        Vehicle car = new Vehicle();

        car.NumPassengers = passengers;

        Assert.That(car.NumPassengers, Is.EqualTo(expected));
    }

    [TestCase(10, 1, 1)]
    [TestCase(10, 5, 5)]
    [TestCase(10, 10, 10)]
    public void GivenValidNumber_Vehicle_NumPassengersSetToExpectedValue(int capacity, int passengers, int expected)
    {
        Vehicle car = new Vehicle(capacity);

        car.NumPassengers = passengers;

        Assert.That(car.NumPassengers, Is.EqualTo(expected));
    }

    [TestCase(1, 0)]
    [TestCase(10, 0)]
    public void GivenValidNumber_ZeroArgConVehicle_NumPassengersSetToExpectedValue(int passengers, int expected)
    {
        Vehicle car = new Vehicle();

        car.NumPassengers = passengers;

        Assert.That(car.NumPassengers, Is.EqualTo(expected));
    }

    [Test]
    public void GivenInitialValue_ZeroArgConVehicle_PositionSetToZero()
    {
        Vehicle car = new Vehicle();

        Assert.That(car.Position, Is.EqualTo(0));
    }

    [Test]
    public void GivenInitialValue_Vehicle_PositionSetToExpectedValue()
    {
        Vehicle car = new Vehicle();

        Assert.That(car.Position, Is.EqualTo(0));
    }

    [Test]

    public void GivenInitialValue_ZeroArgConVehicle_SpeedSetToTen()
    {
        Vehicle car = new Vehicle();

        Assert.That(car.Speed, Is.EqualTo(10));
    }

    [TestCase(1)]
    [TestCase(10)]
    public void GivenNoInput_Vehicle_SpeedSetToExpectedValue(int capacity)
    {
        Vehicle car = new Vehicle(capacity);

        Assert.That(car.Speed, Is.EqualTo(10));

    }

    [TestCase(1, 9, 9)]
    [TestCase(1, 11, 11)]
    [TestCase(1, 25, 25)]
    public void GivenValidInput_Vehicle_SpeedSetToExpectedValue(int capacity, int speed, int expectedSpeed)
    {
        Vehicle car = new Vehicle(capacity, speed);

        Assert.That(car.Speed, Is.EqualTo(expectedSpeed));

    }

    [TestCase(5, 5, 5, "FourPillarsApp.Vehicle capacity: 5 passengers: 5 speed: 5 position: 5")]
    [TestCase(10, 5, 5, "FourPillarsApp.Vehicle capacity: 10 passengers: 5 speed: 5 position: 5")]
    [TestCase(5, 10, 10, "FourPillarsApp.Vehicle capacity: 5 passengers: 5 speed: 10 position: 10")]
    [TestCase(5, 5, -5, "FourPillarsApp.Vehicle capacity: 5 passengers: 0 speed: 5 position: 5")]

    public void GivenValidInput_VehicleToString_ReturnsExpectedString(int capacity, int speed, int passengers, string expected)
    {
        Vehicle car = new Vehicle(capacity, speed);
        car.NumPassengers = passengers;
        car.Move();
        Assert.That(car.ToString, Is.EqualTo(expected));
    }
}