using FourPillarsApp;

namespace FourPillarsTests;

public class ClassStructsTests
{
    [SetUp]
    public void Setup()
    {
    }
    //test get full name

    //test set name

    // test age setter
    [TestCase(1)]
    [TestCase(99)]
    public void GivenAgeAboveZero_SetAge_SetsValidAge(int age)
    {
        Person person = new Person();
        person.Age = age;

        Assert.That(person.Age, Is.EqualTo(age));
    }

    [TestCase(-9)]
    [TestCase(-1)]
    public void GivenAgeBelowZero_SetAge_SetsAgeToDefault(int age)
    {
        Person person = new Person();
        person.Age = age;

        Assert.That(person.Age, Is.EqualTo(18));
    }
    //write tests to set the name correctly.

    [TestCase("joe", "bloggs")]
    [TestCase("terry", "bloggs")]
    public void GivenFirstNameAndLastName_GetFullName_ReturnsExpectedFullName(string fName, string lName)
    {
        Person person = new Person(fName, lName);

        Assert.That(person.GetFullName(), Is.EqualTo($"{fName} {lName}"));
    }

    [TestCase("Mr", "joe", "bloggs")]
    [TestCase("Mrs", "jenny", "bloggs")]
    public void GivenFirstNameLastNameAndTitle_GetFullName_ReturnsExpectedOutput(string title, string fName, string lName)
    {
        Person person = new Person(fName, lName);

        Assert.That(person.GetFullName(title), Is.EqualTo($"{title} {fName} {lName}"));
    }
}